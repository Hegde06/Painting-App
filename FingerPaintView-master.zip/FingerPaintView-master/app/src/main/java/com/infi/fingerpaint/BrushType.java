package com.infi.fingerpaint;

/**
 * Created by INFIi on 1/21/2017.
 */

public class BrushType {
    static final int BRUSH_SOLID=0;
    static final int BRUSH_NEON=1;
    static final int BRUSH_INNER=2;
    static final int BRUSH_BLUR=3;
    static final int BRUSH_EMBOSS=4;
    static final int BRUSH_DEBOSS=5;

}
